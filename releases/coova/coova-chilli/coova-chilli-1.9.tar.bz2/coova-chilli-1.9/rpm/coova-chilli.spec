Summary:   Coova-Chilli is a Wireless LAN Access Point Controller
Name:      coova-chilli
Version:   1.9
Release:   1%{?dist}
URL:       http://coova.github.io/
Source0:   %{name}-%{version}.tar.gz
License:   GPL
Group:     System Environment/Daemons

%if %{!?_without_ssl:1}0
BuildRequires: openssl-devel libtool gengetopt
%endif

%description

Coova-Chilli is a fork of the ChilliSpot project - an open source captive
portal or wireless LAN access point controller. It supports web based login
(Universal Access Method, or UAM), standard for public HotSpots, and it
supports Wireless Protected Access (WPA), the standard for secure roamable
networks. Authentication, Authorization and Accounting (AAA) is handled by
your favorite radius server. Read more at http://coova.github.io/.

%prep
%setup

%build
sh bootstrap
%configure \
        --disable-static \
        --enable-shared \
	--enable-largelimits \
	--enable-miniportal \
	--enable-chilliredir \
	--enable-chilliproxy \
        --enable-chilliscript \
	--with-poll \
    --enable-libjson \
%if %{!?_without_ssl:1}0
	--with-openssl \
	--enable-chilliradsec \
%endif


make

%install
make install DESTDIR=$RPM_BUILD_ROOT

rm -rf $RPM_BUILD_ROOT%{_prefix}/include/*
rm -f $RPM_BUILD_ROOT%{_libdir}/*.la
rm -f $RPM_BUILD_ROOT%{_libdir}/*.a
#cp -f chilli $RPM_BUILD_ROOT%{_sysconfdir}/init.d/chilli

%check
rm -f $RPM_BUILD_ROOT%{_libdir}/python/*.pyc
rm -f $RPM_BUILD_ROOT%{_libdir}/python/*.pyo

%clean
rm -rf $RPM_BUILD_ROOT
make clean

%post
/sbin/chkconfig --add chilli

%preun
if [ $1 = 0 ]; then
        /sbin/service chilli stop > /dev/null 2>&1
        /sbin/chkconfig --del chilli
fi

%files
%defattr(-,root,root)
%{_sbindir}/*
%{_libdir}/*.so*
%{_libdir}/python/CoovaChilliLib.py
%{_sysconfdir}/init.d/chilli
%doc AUTHORS COPYING ChangeLog INSTALL README doc/dictionary.coovachilli doc/hotspotlogin.cgi
%config %{_sysconfdir}/chilli.conf
%config %{_sysconfdir}/chilli/gui-config-default.ini
%config(noreplace) %{_sysconfdir}/chilli/defaults
%dir %{_sysconfdir}/chilli
%dir %{_sysconfdir}/chilli/www
%attr(755,root,root)%{_sysconfdir}/chilli/www/config.sh
%attr(4750,root,root)%{_sbindir}/chilli_script
%{_sysconfdir}/chilli/www/*
%{_sysconfdir}/chilli/wwwsh
%{_sysconfdir}/chilli/functions
%{_sysconfdir}/chilli/*.sh
%{_sysconfdir}/chilli/wpad.dat
%{_mandir}/man1/*.1*
%{_mandir}/man5/*.5*
%{_mandir}/man8/*.8*

%changelog

* Tue Apr 21 2026 Guillaume Marsay <gmarsay@gmail.com>
- 1.9 release

* Fri Nov 28 2025 Guillaume Marsay <gmarsay@gmail.com>
- 1.8 release

* Wed Aug 20 2025 Sevan Janiyan <venture37@geeklan.co.uk>
- 1.7 release

* Sat Feb 20 2021 Sevan Janiyan <venture37@geeklan.co.uk>
- 1.6 release

* Fri Jun 26 2015 Giovanni Bezicheri <giovanni.bezicheri@nethesis.it>
* Fix json encoding for radius reply.

* Tue May 13 2015 Giovanni Bezicheri <giovanni.bezicheri@nethesis.it>
* Add support for json uri.

* Fri Nov 14 2014 Giovanni Bezicheri <giovanni.bezicheri@nethesis.it>
- Add HS_LANIF_KEEPADDR option in chilli sysconfig.

* Thu Jul 10 2014 Giovanni Bezicheri <giovanni.bezicheri@nethesis.it>
- 1.3.1 release for NethServer. See ChangeLog.

* Sat Jan 2 2010 <david@coova.com>
- 1.2.0 release
* Thu Sep 30 2007 <david@coova.com>
- 1.0.8 release 
* Thu Aug 20 2007 <david@coova.com>
- 1.0-coova.7 release
* Thu Jun 7 2007 <david@coova.com>
- 1.0-coova.6 release
* Wed May 16 2007  <david@coova.com>
- 1.0-coova.5 release
* Wed Feb 07 2007  <david@coova.com>
- 1.0-coova.4 release
* Wed Nov 15 2006  <david@coova.com>
- 1.0-coova.3 release
* Thu Mar 25 2004  <support@chillispot.org>
- Initial release.
